package nova.js.nodewriters;

import net.fathomsoft.nova.tree.variables.FieldList;

public abstract class FieldListWriter extends ListWriter
{
	public abstract FieldList node();
	
	
}