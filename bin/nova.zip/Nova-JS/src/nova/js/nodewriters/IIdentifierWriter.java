package nova.js.nodewriters;

public abstract class IIdentifierWriter extends IdentifierWriter
{
	
}