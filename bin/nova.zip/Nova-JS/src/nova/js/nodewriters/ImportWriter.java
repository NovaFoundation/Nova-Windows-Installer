package nova.js.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ImportWriter extends NodeWriter
{
	public abstract Import node();
	
	
}