package nova.js.nodewriters;

import net.fathomsoft.nova.tree.variables.VariableDeclarationList;

public abstract class VariableDeclarationListWriter extends ListWriter
{
	public abstract VariableDeclarationList node();
}