package nova.js.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ContinueWriter extends NodeWriter
{
	public abstract Continue node();
	
	
}