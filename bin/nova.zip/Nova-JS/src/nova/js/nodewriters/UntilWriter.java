package nova.js.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class UntilWriter extends IfStatementWriter
{
	public abstract Until node();
	
	
}