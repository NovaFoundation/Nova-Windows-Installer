package nova.js.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ClosureDeclarationWriter extends ParameterWriter
{
	public abstract ClosureDeclaration node();
	
	
}