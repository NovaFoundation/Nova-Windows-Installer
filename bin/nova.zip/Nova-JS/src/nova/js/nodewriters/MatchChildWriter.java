package nova.js.nodewriters;

public abstract class MatchChildWriter extends NodeWriter
{
	
}