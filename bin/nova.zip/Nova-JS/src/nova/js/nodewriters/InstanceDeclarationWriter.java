package nova.js.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class InstanceDeclarationWriter extends VariableDeclarationWriter
{
	public abstract InstanceDeclaration node();
	
	
}