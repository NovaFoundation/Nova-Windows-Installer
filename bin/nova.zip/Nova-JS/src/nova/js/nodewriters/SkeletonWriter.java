package nova.js.nodewriters;

public abstract class SkeletonWriter extends NodeWriter 
{
	
}