package nova.js.nodewriters;

public abstract class MatchCaseWriter extends NodeWriter
{
	
}