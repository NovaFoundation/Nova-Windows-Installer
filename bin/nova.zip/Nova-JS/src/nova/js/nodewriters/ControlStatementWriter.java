package nova.js.nodewriters;

public abstract class ControlStatementWriter extends NodeWriter
{
	
}