package nova.js.nodewriters;

import net.fathomsoft.nova.tree.variables.InstanceFieldList;

public abstract class InstanceFieldListWriter extends ListWriter
{
	public abstract InstanceFieldList node();
	
	
}