package nova.java.nodewriters;

public abstract class ExceptionHandlerWriter extends NodeWriter
{
	
}