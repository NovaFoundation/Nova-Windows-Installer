package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class IValueWriter extends ValueWriter
{
	public abstract IValue node();
	
	
}