package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class PropertyMethodWriter extends BodyMethodDeclarationWriter
{
	public abstract PropertyMethod node();
	
	
}