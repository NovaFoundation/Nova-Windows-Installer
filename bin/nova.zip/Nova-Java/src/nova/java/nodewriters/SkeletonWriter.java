package nova.java.nodewriters;

public abstract class SkeletonWriter extends NodeWriter 
{
	
}