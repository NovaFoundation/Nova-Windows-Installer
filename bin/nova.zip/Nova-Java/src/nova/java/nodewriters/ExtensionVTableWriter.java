package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ExtensionVTableWriter extends VTableWriter
{
	public abstract ExtensionVTable node();
	
	
}