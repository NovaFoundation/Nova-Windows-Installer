package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class StaticBlockWriter extends NodeWriter
{
	public abstract StaticBlock node();
	
	
}