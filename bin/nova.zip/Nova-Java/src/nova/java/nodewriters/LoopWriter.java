package nova.java.nodewriters;

public abstract class LoopWriter extends NodeWriter
{
	
}