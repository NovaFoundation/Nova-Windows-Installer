package nova.java.nodewriters;

import net.fathomsoft.nova.tree.variables.StaticFieldList;

public abstract class StaticFieldListWriter extends ListWriter
{
	public abstract StaticFieldList node();
	
	
}