package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class DestructorWriter extends BodyMethodDeclarationWriter
{
	public abstract Destructor node();
	
	
}