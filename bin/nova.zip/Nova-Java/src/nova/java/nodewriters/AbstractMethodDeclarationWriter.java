package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class AbstractMethodDeclarationWriter extends NovaMethodDeclarationWriter
{
	public abstract AbstractMethodDeclaration node();
}