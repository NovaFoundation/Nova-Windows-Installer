package nova.java.nodewriters;

import net.fathomsoft.nova.tree.variables.Variable;

public abstract class VariableWriter extends IdentifierWriter
{
	public abstract Variable node();
	
	
}