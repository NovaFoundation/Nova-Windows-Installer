package nova.java.nodewriters;

public abstract class IIdentifierWriter extends IdentifierWriter
{
	
}