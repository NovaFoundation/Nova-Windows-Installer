package nova.java.nodewriters;

public abstract class MatchCaseWriter extends NodeWriter
{
	
}