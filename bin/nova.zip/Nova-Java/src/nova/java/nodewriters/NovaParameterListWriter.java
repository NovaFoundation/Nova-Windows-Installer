package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class NovaParameterListWriter extends ParameterListWriter
{
	public abstract NovaParameterList node();
	
	
}