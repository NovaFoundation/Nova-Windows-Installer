package nova.java.nodewriters;

public abstract class MatchChildWriter extends NodeWriter
{
	
}