package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ClosureParameterListWriter extends ParameterListWriter
{
	public abstract ClosureParameterList node();
	
	
}