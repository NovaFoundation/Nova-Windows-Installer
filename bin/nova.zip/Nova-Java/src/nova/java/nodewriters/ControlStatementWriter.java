package nova.java.nodewriters;

public abstract class ControlStatementWriter extends NodeWriter
{
	
}