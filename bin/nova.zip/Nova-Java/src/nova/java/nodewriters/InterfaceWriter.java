package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class InterfaceWriter extends ClassDeclarationWriter
{
	public abstract Interface node();
	
	
}