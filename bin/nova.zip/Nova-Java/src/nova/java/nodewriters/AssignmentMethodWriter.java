package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class AssignmentMethodWriter extends BodyMethodDeclarationWriter
{
	public abstract AssignmentMethod node();
	
	
}