package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class TypeListWriter extends ListWriter
{
	public abstract TypeList node();
	
	
}