package nova.java.nodewriters;

import net.fathomsoft.nova.tree.*;

public abstract class ImportListWriter extends TypeListWriter
{
	public abstract ImportList node();
	
	
}