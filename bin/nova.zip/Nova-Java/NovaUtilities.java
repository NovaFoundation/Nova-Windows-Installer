public class NovaUtilities
{
@FunctionalInterface
public static interface Function20<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20>
{
T20 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14, T15 t15, T16 t16, T17 t17, T18 t18, T19 t19);
}
@FunctionalInterface
public static interface Function19<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19>
{
T19 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14, T15 t15, T16 t16, T17 t17, T18 t18);
}
@FunctionalInterface
public static interface Function18<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18>
{
T18 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14, T15 t15, T16 t16, T17 t17);
}
@FunctionalInterface
public static interface Function17<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17>
{
T17 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14, T15 t15, T16 t16);
}
@FunctionalInterface
public static interface Function16<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>
{
T16 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14, T15 t15);
}
@FunctionalInterface
public static interface Function15<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>
{
T15 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13, T14 t14);
}
@FunctionalInterface
public static interface Function14<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>
{
T14 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12, T13 t13);
}
@FunctionalInterface
public static interface Function13<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>
{
T13 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11, T12 t12);
}
@FunctionalInterface
public static interface Function12<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>
{
T12 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10, T11 t11);
}
@FunctionalInterface
public static interface Function11<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>
{
T11 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9, T10 t10);
}
@FunctionalInterface
public static interface Function10<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>
{
T10 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8, T9 t9);
}
@FunctionalInterface
public static interface Function9<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9>
{
T9 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7, T8 t8);
}
@FunctionalInterface
public static interface Function8<T0, T1, T2, T3, T4, T5, T6, T7, T8>
{
T8 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6, T7 t7);
}
@FunctionalInterface
public static interface Function7<T0, T1, T2, T3, T4, T5, T6, T7>
{
T7 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6);
}
@FunctionalInterface
public static interface Function6<T0, T1, T2, T3, T4, T5, T6>
{
T6 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4, T5 t5);
}
@FunctionalInterface
public static interface Function5<T0, T1, T2, T3, T4, T5>
{
T5 call(T0 t0, T1 t1, T2 t2, T3 t3, T4 t4);
}
@FunctionalInterface
public static interface Function4<T0, T1, T2, T3, T4>
{
T4 call(T0 t0, T1 t1, T2 t2, T3 t3);
}
@FunctionalInterface
public static interface Function3<T0, T1, T2, T3>
{
T3 call(T0 t0, T1 t1, T2 t2);
}
@FunctionalInterface
public static interface Function2<T0, T1, T2>
{
T2 call(T0 t0, T1 t1);
}
@FunctionalInterface
public static interface Function1<T0, T1>
{
T1 call(T0 t0);
}
@FunctionalInterface
public static interface Function0<T0>
{
T0 call();
}
